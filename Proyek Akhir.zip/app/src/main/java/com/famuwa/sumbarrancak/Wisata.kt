package com.famuwa.sumbarrancak

data class Wisata (
    var wisataName : String = "",
    var wisataLocation : String = "",
    var wisataDetail : String = "",
    var wisataPhoto : Int = 0
)