package com.famuwa.sumbarrancak

data class Makanan (
    var namaMakanan : String = "",
    var deskripsiMakanan : String = "",
    var photoMakanan : Int = 0
)